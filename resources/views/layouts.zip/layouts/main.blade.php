<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script defer src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.js" integrity="sha512-WNZwVebQjhSxEzwbettGuQgWxbpYdoLf7mH+25A7sfQbbxKeS5SQ9QBf97zOY4nOlwtksgDA/czSTmfj4DUEiQ==" crossorigin="anonymous"></script>
    <script src="/js/main.js"></script>
    <link rel=stylesheet href=https://pro.fontawesome.com/releases/v5.10.0/css/all.css integrity=sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p crossorigin=anonymous>
    <link rel=icon href=/favicon.ico> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="/css/main.css" rel='stylesheet'>
    <title>Aibek sait</title>
</head>

<body>
    @section('header')
    <div>
        <div class="header">
            <div class="nav-top">
                <div class="container">
                    <nav>
                        <button class="navbar-toggler bg-dark" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarToggleExternalContent">
                            <ul>
                                <li>
                                    <a href="#">О КОМПАНИИ</a>
                                </li>
                                <li>
                                    <a href="#">ДОСТАВКА</a>
                                </li>
                                <li>
                                    <a href="#">ОПЛАТА</a>
                                </li>
                                <li>
                                    <a href="#">СОТРУДНИЧЕСТВО</a>
                                </li>
                                <li>
                                    <a href="#">СЕРВИС</a>
                                </li>
                                <li>
                                    <a href="#">КОНТАКТЫ</a>
                                </li>
                            </ul>
                        </div>

                    </nav>

                </div>
            </div>
        </div>
        <div class="nav-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-2">
                        <div class="logo">
                            <img src="/storage/main/logo.png" alt />
                        </div>
                    </div>
                    <div class="col-xl-10 pl-5">
                        <div class="nav-content">
                            <div class="logo-title">
                                <p>Настоящее немецкое качество</p>
                            </div>
                            <div class="nav-right">
                                <div class="phone">
                                    <a href="tel: +7 495 374 68 54">
                                        <i class="fas fa-phone-alt"></i>
                                        <span>+7 495</span> 374 68 54
                                    </a>
                                </div>
                                <div class="icon">
                                    <span>
                                        <i class="fas fa-chart-bar"></i>
                                        1
                                    </span>
                                    <span>
                                        <i class="fas fa-bookmark"></i>
                                        0
                                    </span>
                                    <span>
                                        <i class="fas fa-shopping-basket"></i>1
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="home-category">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7">
                        <div class="home-left">
                            <span class="blue-text">
                                <a href="#">
                                    <i class="fas fa-home"></i>
                                </a>
                            </span>
                            <ul>
                                <li>
                                    <a href="#" class="colection-btn">Коллекции</a>
                                </li>
                                <li class="category">
                                    <a href="#" class="colection-btn">
                                        Каталог
                                        <i class="fas fa-chevron-down"></i>
                                    </a>
                                    <ul class="dropdown-main">
                                        <li class="dropdown-link">
                                            <a href="#">link</a>
                                            <ul class="dropdown-children">
                                                <li>
                                                    <a href="#">item1</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-link">
                                            <a href="#">link</a>
                                            <ul class="dropdown-children">
                                                <li>
                                                    <a href="#">item2</a>
                                                </li>
                                                <li>
                                                    <a href="#">item2</a>
                                                </li>
                                                <li>
                                                    <a href="#">item2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown-link">
                                            <a href="#">link</a>
                                            <ul class="dropdown-children">
                                                <li>
                                                    <a href="#">item3</a>
                                                </li>
                                                <li>
                                                    <a href="#">item3</a>
                                                </li>
                                                <li>
                                                    <a href="#">item3</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-5">
                        <form action>
                            <input type="text" placeholder="Поиск" />
                            <button type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @show

    @yield('main')

    @section('footer')
    <div>
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <h5>ИДЕИ И ТЕХНОЛОГИИ</h5>
                        <ul>
                            <li>
                                <a href="#">ENJOY DESIGN</a>
                            </li>
                            <li>
                                <a href="#">ПЕРЕДОВОЕ ПРОИЗВОДСТВО</a>
                            </li>
                            <li>
                                <a href="#">СОВРЕМЕННЫЙ ДИЗАЙН</a>
                            </li>
                            <li>
                                <a href="#">ГАРАНТИЯ 5 ЛЕТ</a>
                            </li>
                            <li>
                                <a href="#">НЕМЕЦКОЕ КАЧЕСТВО</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <h5>КАТАЛОГ ПРОДУКЦИИ</h5>
                        <ul>
                            <li>
                                <a href="#">СМЕСИТЕЛИ</a>
                            </li>
                            <li>
                                <a href="#">ВОДОСНАБЖЕНИЕ</a>
                            </li>
                            <li>
                                <a href="#">ДУШЕВЫЕ УГЛЫ И ОГРАЖДЕНИЯ</a>
                            </li>
                            <li>
                                <a href="#">ДВЕРИ В НИШУ</a>
                            </li>
                            <li>
                                <a href="#">ШТОРКИ ДЛЯ ВАННЫ</a>
                            </li>
                            <li>
                                <a href="#">ДУШЕВЫЕ ПОДДОНЫ</a>
                            </li>
                            <li>
                                <a href="#">КОМПЛЕКТУЮЩИЕ ДЛЯ ДУШЕВЫХ ПОДДОНОВ</a>
                            </li>
                            <li>
                                <a href="#">ДУШЕВЫЕ СИСТЕМЫ</a>
                            </li>
                            <li>
                                <a href="#">АКСЕССУАРЫ</a>
                            </li>
                            <li>
                                <a href="#">РАКОВИНЫ</a>
                            </li>
                            <li>
                                <a href="#">ЗЕРКАЛА</a>
                            </li>
                            <li>
                                <a href="#">ДРЕНАЖНЫЕ КАНАЛЫ</a>
                            </li>
                            <li>
                                <a href="#">КОМПЛЕКТУЮЩИЕ ДЛЯ СМЕСИТЕЛЕЙ</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <h5>ОБЩАЯ ИНФОРМАЦИЯ</h5>
                        <ul>
                            <li>
                                <a href="#">О КОМПАНИИ</a>
                            </li>
                            <li>
                                <a href="#">РЕКВИЗИТЫ</a>
                            </li>
                            <li>
                                <a href="#">ДОСТАВКА</a>
                            </li>
                            <li>
                                <a href="#">ОПЛАТА</a>
                            </li>
                            <li>
                                <a href="#">СОТРУДНИЧЕСТВО</a>
                            </li>
                            <li>
                                <a href="#">СЕРВИС</a>
                            </li>
                            <li>
                                <a href="#">КОНТАКТЫ</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <div class="phone">
                            <a href="tel: +7 495 374 68 54">
                                <i class="fas fa-phone-alt"></i>
                                <span>+7 495</span> 374 68 54
                            </a>
                        </div>
                        <ul>
                            <li>
                                <a href="#">
                                    ЗАПРОСИТЬ ПРАЙС-ЛИСТ
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </li>
                        </ul>
                        <p class="silver-text">GAPPO В СОЦСЕТЯХ:</p>
                        <ul class="social">
                            <li>
                                <a href="#">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fab fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fab fa-odnoklassniki"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fab fa-vk"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <div class="bottom-footer">
            <div class="container">
                <div class="bottom-footer-text">
                    <div class="bottom-text">
                        <div class="logo">
                            <img src="@/assets/images/logo.png" alt />
                        </div>
                        <p>© 2016 GAPPO. ТЕХНОЛОГИИ ЛИДЕРСТВА.</p>
                    </div>
                    <div class="bottom-text">
                        <p>ВСЕ ПРАВА ЗАЩИЩЕНЫ.СОЗДАНИЕ САЙТА: SMARTSOFT</p>
                        <div class="logo">
                            <img src="@/assets/images/logo.png" alt />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @show
</body>

</html>